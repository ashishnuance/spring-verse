/*
* Navbar - Sidenav
*/
$(function() {
	$(".dropdown-trigger").dropdown();
	$(".button-collapse").sidenav();
});