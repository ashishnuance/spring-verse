/*
 * Knowledge Page
 */

// Sidenav

$(document).ready(function(){
  $('.licenses-list li').click(function(){
    $('li').removeClass("active");
    $(this).addClass("active");
  });
});