<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Auth\User\User;
use Kreait\Firebase\Contract\Database;



class UserController extends Controller
{
    
    public function __construct()
    {
        
    }

    private $member_select_col = ['id','name','email','phone','active_status'];
    
    public function usersList()
    {
        
        $userlist = [];
        $userlist = User::select($this->member_select_col)->with('roles')->whereHas('roles',function($q){
            $q->whereIn('role_id',[2,3]);
        });
        if(!empty($userlist) && $userlist->count()>0){
            $userlist = $userlist->get();
        }
        $extraurl=[];
        $extraurl['editlink'] = 'edit-user';
        $extraurl['deletelink'] = 'delete-user';
        $breadcrumbs = [
            ['link' => "/", 'name' => "Home"], ['link' => "javascript:void(0)", 'name' => "User"], ['name' => "Users List"]];
        //Pageheader set true for breadcrumbs
        $pageConfigs = ['pageHeader' => true, 'isFabButton' => false];
        // return view('pages.page-users-list', 
        $table_header = ['S.No','name','email','phone','role','status'];
        return view('pages.list-page', ['pageConfigs' => $pageConfigs], ['breadcrumbs' => $breadcrumbs,'resultlist'=>$userlist,'table_header'=>$table_header,'extraurl'=>$extraurl]);
    }
    public function usersView()
    {
        $breadcrumbs = [
            ['link' => "modern", 'name' => "Home"], ['link' => "javascript:void(0)", 'name' => "User"], ['name' => "Users View"]];
        //Pageheader set true for breadcrumbs
        $pageConfigs = ['pageHeader' => true, 'isFabButton' => true];

        return view('pages.page-users-view', ['pageConfigs' => $pageConfigs], ['breadcrumbs' => $breadcrumbs]);
    }
    public function usersEdit()
    {
        $breadcrumbs = [
            ['link' => "modern", 'name' => "Home"], ['link' => "javascript:void(0)", 'name' => "User"], ['name' => "Users Edit"]];
        //Pageheader set true for breadcrumbs
        $pageConfigs = ['pageHeader' => true, 'isFabButton' => true];
        return view('pages.page-users-edit', ['pageConfigs' => $pageConfigs], ['breadcrumbs' => $breadcrumbs]);
    }

}
