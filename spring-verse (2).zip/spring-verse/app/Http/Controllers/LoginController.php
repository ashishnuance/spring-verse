<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;


class LoginController extends Controller
{
    
    public function __construct()
    {
        
            if (session('success')) {
                Alert::success(session('success'));
            } 
            if (session('error')) {
                Alert::error(session('error'));
            }
        
    }

    public function login()
    {
        
        return view('frontend.login');
    }

    /**
     * member login process
    **/
    public function memberLogin(Request $request) {
        // print_r($request->all());
        $validate = Validator::make($request->all(), [
            'username' => 'required',
            'password' => 'required',
        ]);

        if ( $validate->fails() ) {
            return redirect()->back()->withErrors($validate)->withInput();
        }

        $user_data = User::where('username',$request->username);
        if($user_data->count()>0){
            
            // match password
            if (Hash::check($request->password, $user_data->first()->password)) {
                Auth::login($user_data);
                return redirect()->route('home');  
            } else {
                return redirect()->back()->with('error', 'Password correct');    
            }
        }else{
            return redirect()->back()->with('error', 'Username not correct');
            // return redirect()->back()->withError('');
        }

        exit();
    }
}
