<?php
  
use Carbon\Carbon;
  

if (!function_exists('print_die')) {

  function print_die($userlist){
      return json_decode($userlist);
  }
}